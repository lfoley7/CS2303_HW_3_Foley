/*
 * Room.h
 *
 *  Created on: Mar 16, 2021
 *      Author: Luke Foley
 */

#ifndef ROOM_H_
#define ROOM_H_

#include <stdbool.h>

typedef struct
{
	int roomNumber;
	float treasure;
	bool searched;
}Room;

#endif /* ROOM_H_ */
