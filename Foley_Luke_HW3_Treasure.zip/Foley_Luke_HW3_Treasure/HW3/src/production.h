/*
 * production.h
 *
 *  Created on: Mar 16, 2021
 *      Author: Luke Foley
 */

#ifndef PRODUCTION_H_
#define PRODUCTION_H_
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include "AdjMat.h"
#include "Room.h"

#define FILENAMELENGTHALLOWANCE 50

bool production(int argc, char* argv[]);
bool readFile(char* filename, int* nrooms, AdjMat* adjMP, Room** theRoomPs);
void displayBoard();

#endif /* PRODUCTION_H_ */
