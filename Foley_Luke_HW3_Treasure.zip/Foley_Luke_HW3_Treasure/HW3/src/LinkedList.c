/*
 * LinkedList.c
 *
 *  Created on: Nov 4, 2019
 *      Author: Therese
 */

#include "LinkedList.h"
#include <stdlib.h>
#include <stdio.h>

bool isEmpty(LLNode* lp)
{
	bool ans = false;
	if(lp->payP == (Payload*)0)
	{
		ans = true;
	}
	return ans;
}

bool isEmpty2(LLNode2* lp)
{
	bool ans = false;
	if(lp->payP == (Payload2*)0)
	{
		ans = true;
	}
	return ans;
}

LLNode* makeEmptyLinkedList()
{
	LLNode* lp = (LLNode*) malloc(sizeof(LLNode));
	lp->next = (struct LLNode*)0;
	lp->prev = (struct LLNode*)0;
	lp->payP = (Payload*)0;
	return lp;
}

LLNode2* makeEmptyLinkedList2()
{
	LLNode2* lp = (LLNode2*) malloc(sizeof(LLNode2));
	lp->next = (struct LLNode2*)0;
	lp->prev = (struct LLNode2*)0;
	lp->payP = (Payload2*)0;
	return lp;
}

void savePayload(LLNode* lp, Payload* mp)
{
	if(isEmpty(lp))
	{
		lp->payP = mp;
	}
	else
	{
		LLNode* temp = lp;
		while(temp->next)
		{
			temp=(LLNode*)temp->next;
		}
		LLNode* newList = makeEmptyLinkedList();
		newList->payP = mp;
		temp->next = (struct LLNode*)newList;
		newList->prev = (struct LLNode*) temp;
	}
}

void savePayload2(LLNode2* lp, Payload2* mp)
{
	if(isEmpty2(lp))
	{
		lp->payP = mp;
	}
	else
	{
		LLNode2* temp = lp;
		while(temp->next)
		{
			temp=(LLNode2*)temp->next;
		}
		LLNode2* newList = makeEmptyLinkedList2();
		newList->payP = mp;
		temp->next = (struct LLNode2*) newList;
		newList->prev = (struct LLNode2*) temp;
	}
}

Payload* dequeueLIFO(LLNode* lp)
{
	Payload* payP = (Payload*)0;
	if(isEmpty(lp))
	{
		puts("Trying to dequeue from empty.");
	}
	else
	{
		LLNode* temp = lp;
		while(temp->next)
		{
			temp=(LLNode*)temp->next;
		}
		payP = temp->payP;
		temp->payP = (Payload*)0;
		printf("Room being returned is %d\n", payP->roomNumber); fflush(stdout);
		if(temp->prev)
		{
			temp=(LLNode*)temp->prev;
			printf("end of queue is room %d\n", temp->payP->roomNumber);fflush(stdout);
			temp->next = (struct LLNode*)0;
		}
		else
		{
			puts("Queue is now empty");
		}
		puts("returning from dequeue");fflush(stdout);
	}
	return payP;
}

backFromDQFIFO* dequeueFIFO(LLNode* lp)
{
	backFromDQFIFO* fp = (backFromDQFIFO*) malloc(sizeof(backFromDQFIFO));
	if(lp->next == (struct LLNode*)0)
	{
		fp->newQHead= lp;
	}
	else
	{
		fp->newQHead= (LLNode*) lp->next;
	}
	fp->mp= lp->payP;
	if(lp->next != (struct LLNode*)0)
	{
		free(lp);
	}
	return fp;
}

void printHistory(LLNode2* hp)
{
    puts("Printing history");
    if(hp->payP ==(Payload2*)0)
    {
         puts("Empty list");
    }
    else
    {
        float treasureSubtotal = 0.0;
        int room = -1;
        LLNode2* temp = hp;
        while(temp->next)
        {
            room = temp->payP->roomNumber;
            treasureSubtotal+= temp->payP->treasure;
            printf("The room was %d, and the treasure subtotal1 was %f.\n", room, treasureSubtotal);
            printf("%d\n", room);
            temp=(LLNode2*)temp->next;
        }
        room = temp->payP->roomNumber;
        treasureSubtotal+= temp->payP->treasure;
        printf("The room was %d, and the treasure subtotal1 was %f.\n", room, treasureSubtotal);
    }
}

LLNode* removeFromList(LLNode* hP, Payload* pP)
{
	LLNode* retHead = hP;
	if(!isEmpty(hP))
	{
		LLNode* altHead = (LLNode*)hP->next;
		LLNode* temp = hP;
		bool done = false;
		while((!done) && temp->next)
		{
			if(temp->payP == pP)
			{
				done=true;
			}
			else
			{
				temp=(LLNode*)temp->next;
			}
		}
		if((temp->payP) == pP)
		{
			if(temp == hP)
			{
				if(!(temp->next))
				{
					hP->payP = (Payload*)0;
				}
				else
				{
					retHead = altHead;
				}
			}
			else
			{
				LLNode* prevPart = (LLNode*) temp->prev;
				LLNode* nextPart = (LLNode*) temp->next;
				prevPart->next = (struct LLNode*) nextPart;
				if((bool)nextPart)
				{
					nextPart->prev = (struct LLNode*) prevPart;
				}
			}
		}
	}
	return retHead;
}
