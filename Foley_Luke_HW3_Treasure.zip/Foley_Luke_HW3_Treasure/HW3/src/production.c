/*
 * production.c
 *
 *  Created on: Mar 16, 2021
 *      Author: Luke Foley
 */
#include "production.h"
#include "AdjMat.h"
#include "Room.h"
#include "LinkedList.h"

bool production(int argc, char* argv[])
{
	bool answer = false;
	if(argc <=1) //no interesting information
	{
		puts("Didn't find any arguments.");
		fflush(stdout);
		answer = false;
	}
	else //there is interesting information
	{
		printf("Found %d interesting arguments.\n", argc-1);
		fflush(stdout);
		char filename[FILENAMELENGTHALLOWANCE];
		char* eptr=(char*) malloc(sizeof(char*));
		long aL=-1L;
		int maxRooms;
		float maxTreasure;
		double maxTreas;
		for(int i = 1; i<argc; i++) //don't want to read argv[0]
		{//argv[i] is a string
			//in this program our arguments are NR, NC, gens, filename, print and pause
			//because pause is optional, argc could be 6 or 7
			//because print is optional (if print is not present, neither is pause) argc could be 5
			switch(i)
			{
			case 1:
				//this is filename
				printf("The length of the filename is %d.\n",strlen(argv[i]));
				printf("The proposed filename is %s.\n", argv[i]);
				if(strlen(argv[i])>=FILENAMELENGTHALLOWANCE)
				{
					puts("Filename is too long.");
					fflush(stdout);
					answer = false;
				}
				else
				{
					strcpy(filename, argv[i]);
					printf("Filename was %s.\n", filename);
					fflush(stdout);
				}
				break;
			case 2:
				//this is maximum number of rooms
				aL= strtol(argv[i], &eptr, 10);
				maxRooms = (int) aL;
				printf("Number of rooms is %d\n",maxRooms);fflush(stdout);
				break;
			case 3:
				//this is maximum amount of treasure
				maxTreas = atof(argv[i]);
				printf("Amount of  treasure is %f\n",maxTreas);fflush(stdout);
				maxTreasure = (float) maxTreas;
				break;
			default:
				puts("Unexpected argument count."); fflush(stdout);
				answer = false;
				break;
			}//end of switch
		}//end of for loop on argument count
		puts("after reading arguments"); fflush(stdout);
		int nrooms = -1;
		AdjMat* adjMP = (AdjMat*) malloc(sizeof(AdjMat));
		Room* theRoomPs[10];
		puts("Before read file"); fflush(stdout);
		answer = readFile(filename, &nrooms, adjMP, theRoomPs);
		puts("Back from read file"); fflush(stdout);
		LLNode2* historyP = makeEmptyLinkedList2();
		LLNode* searchQ = makeEmptyLinkedList();
		puts("starting search"); fflush(stdout);
		bool done = false;
		int searchedRooms = 0;
		float foundTreasure = 0.0;
		Room* roomBeingSearchedP = theRoomPs[0];
		roomBeingSearchedP->searched = true;
		SearchResults* srP = (SearchResults*) malloc(sizeof(SearchResults));
		srP->roomNumber= 0;
		srP->treasure = roomBeingSearchedP->treasure;
		if((srP->treasure <= maxTreas) && (maxRooms>0))
		{
			puts("Enqueueing room 0");
			savePayload(searchQ, roomBeingSearchedP);
			savePayload2(historyP,srP);
			foundTreasure += srP-> treasure;
		}
		else if (srP->treasure > maxTreas)
		{
			srP->treasure = (float) maxTreas;
			savePayload(searchQ, roomBeingSearchedP);
			savePayload2(historyP,srP);
			foundTreasure = (float)maxTreas;
			done = true;
		}
		else
		{done = true;}
		while(!done)
		{
			for(int col = 0; (col<nrooms)&&!done; col++)
			{
				printf("checking rooms %d and %d.\n", roomBeingSearchedP->roomNumber, col); fflush(stdout);
				if(getEdge(adjMP,roomBeingSearchedP->roomNumber, col)==1)
				{
					puts("found an edge"); fflush(stdout);
					if(!(theRoomPs[col]->searched))
					{
						printf("Room %d hasn't already been searched.\n", col);
						theRoomPs[col]->searched=true;
						if(maxRooms>searchedRooms && maxTreasure>foundTreasure)
						{
							foundTreasure += roomBeingSearchedP->treasure;
							searchedRooms++;
							printf("found treasure updated to %f.\n", foundTreasure);
							printf("enqueuing room %d.\n", col); fflush(stdout);
							printf("Before enqueuing queue empty reports %d\n", isEmpty(searchQ));
							savePayload(searchQ,roomBeingSearchedP);
							savePayload(searchQ,theRoomPs[col]);
							srP = (SearchResults*) malloc(sizeof(SearchResults));
							srP->roomNumber=theRoomPs[col]->roomNumber;
							srP->treasure = theRoomPs[col]->treasure;
							savePayload2(historyP, srP);
							printf("After enqueuing, queue empty reports %d\n", isEmpty(searchQ));
						}
					}
				}
				if(foundTreasure >= maxTreasure)
				{
					done = true;
					puts("Done by treasure");
				}
				if (searchedRooms>=maxRooms)
				{
					done = true;
					puts("Done by rooms");
				}
			}
			if(isEmpty(searchQ))
			{
				done=true;
				puts("Done by queue empty");
			}
			if(!done)
			{
				puts("Invoking  dequeue");fflush(stdout);
				roomBeingSearchedP = dequeueLIFO(searchQ);
			}
		}
		printHistory(historyP);
	}
	return answer;
}
bool readFile(char* filename, int* nrooms, AdjMat* adjMP, Room** theRoomPs)
{
	bool ok = false;
	FILE* fp = fopen(filename, "r");
	if (fp == NULL)
	{
		puts("Error! opening file");
	}
	else
	{
		fscanf(fp,"%d", nrooms);
		adjMP->n=*nrooms;
		int howManyRooms = *nrooms;
		adjMP->edgesP = (int*) malloc(howManyRooms * howManyRooms *sizeof(int));
		puts("Before init Adj Mat"); fflush(stdout);
		init(adjMP);
		int temp = -1;
		for(int roomr = 1; roomr<*nrooms; roomr++)
		{
			printf("on row %d\n", roomr);fflush(stdout);
			for(int roomc = 0; roomc<roomr; roomc++)
			{
				fscanf(fp,"%d", &temp);
				printf("in column %d, read %d\n", roomc, temp);fflush(stdout);
				if(temp==1)
				{
					setEdge(adjMP, roomr, roomc);
				}
			}
		}
		float tempTreas = 2.9;
		for(int roomr = 0; roomr<*nrooms; roomr++)
		{
			fscanf(fp,"%f", &tempTreas);
			Room** aRoomP = theRoomPs;
			aRoomP = aRoomP+roomr;
			*aRoomP = (Room*) malloc(sizeof(Room));
			(*aRoomP)->treasure = tempTreas;
			(*aRoomP)->roomNumber = roomr;
			printf("The treasure in room %d is %f\n", roomr, (*aRoomP)->treasure);
		}
		ok = true;
	}
	fclose(fp);
	return ok;
}
