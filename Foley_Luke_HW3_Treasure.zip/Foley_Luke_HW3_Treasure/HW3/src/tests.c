/*
 * tests.c
 *
 *  Created on: Jul 4, 2019
 *      Author: Therese
 */

#include "tests.h"
#include "production.h"
#include "LinkedList.h"

bool tests()
{
	bool answer = false;
	bool ok1 = testReadFile();
	bool ok2 = testGotAdjacencyMatrix();
	bool ok3 = testMakeLList();
	bool ok4 = testEnqueue();
	bool ok5 = testRemoveFromList();
	bool ok6 = testPrintHistory();
	answer = ok1 && ok2 && ok3 && ok4 && ok5 && ok6;
	return answer;
}

bool testEnqueue()
{
	bool ok = true;
	return ok;
}

bool testReadFile()
{
	puts("starting testReadFile"); fflush(stdout);
	bool ok = false;
	int answer = -1;
	int rightAnswer = 8;
	AdjMat* adjMP = (AdjMat*) malloc(sizeof(AdjMat));
	Room* theRoomPs[10];
	ok = readFile("houseGraph.txt", &answer, adjMP, theRoomPs);
	if(ok)
	{
		if(answer!=rightAnswer)
		{
			puts("test failed on number of rooms");
		}
	}
	puts("The adjacency matrix");
	for(int i = 0; i<answer; i++)
	{
		for(int j = 0; j<answer; j++)
		{
			printf("%d",getEdge(adjMP, i, j));
		}
		printf("\n");
	}
	puts("The treasure values");
	for(int i = 0; i<answer; i++)
	{
		printf("%f\n", theRoomPs[i]->treasure);
	}
	return ok;
}

bool testGotAdjacencyMatrix()
{
	bool ans = true;
	return ans;
}

bool testMakeLList()
{
	bool ok = true;
	puts("starting testMakeLList");fflush(stdout);
	LLNode* theListP = makeEmptyLinkedList();
	bool rightAnswer = true;
	Payload* pay1 = (Payload*) malloc(sizeof(Room));
	pay1->roomNumber = 1;
	savePayload(theListP, pay1);
	bool answer = isEmpty(theListP);
	if(answer!=rightAnswer)
	{
		ok = true;
	}
	else
	{
		puts("test make LList did not pass.");
	}
	return ok;
}

bool testRemoveFromList()
{
	bool ok = true;
	LLNode* case1 = makeEmptyLinkedList();
	Payload* pay1 = (Payload*) malloc(sizeof(Room));
	pay1->roomNumber = 1;
	LLNode* ans = removeFromList(case1, pay1);
	if((ans != case1) || (ans->payP != (Payload*)0))
	{
		ok = false;
	}
	printf("testRemove case 1 with %d\n", ok); fflush(stdout);
	savePayload(case1, pay1);
	ans = removeFromList(case1, pay1);
	if((ans != case1) || (ans->payP != (Payload*)0))
	{
		ok = false;
	}
	printf("testRemove case 2 with %d\n", ok); fflush(stdout);
	Payload* pay3 = (Payload*) malloc(sizeof(Room));
	pay3->roomNumber = 3;
	ans = removeFromList(case1, pay3);
	if(ans != case1)
	{
		ok = false;
	}
	printf("testRemove case 3 with %d\n", ok); fflush(stdout);
	case1 = makeEmptyLinkedList();
	pay1 = (Payload*) malloc(sizeof(Room));
	pay1->roomNumber = 1;
	savePayload(case1, pay1);
	pay3 = (Payload*) malloc(sizeof(Room));
	pay3->roomNumber = 3;
	savePayload(case1, pay3);
	ans = removeFromList(case1, pay1);
	if(ans == case1)
	{
		ok = false;
	}
	printf("testRemove case 4 with %d\n", ok); fflush(stdout);
	case1 = makeEmptyLinkedList();
	pay1 = (Payload*) malloc(sizeof(Room));
	pay1->roomNumber = 1;
	savePayload(case1, pay1);
	pay3 = (Payload*) malloc(sizeof(Room));
	pay3->roomNumber = 3;
	savePayload(case1, pay3);
	ans = removeFromList(case1, pay3);
	LLNode* theNext = (LLNode*) ans->next;
	Payload* check = (Payload*) 0;
	if (theNext)
	{
		check = theNext->payP;
	}
	if((ans != case1) || (check != (Payload*)0))
	{
		ok = false;
	}
	printf("testRemove case 5 with %d\n", ok); fflush(stdout);
	case1 = makeEmptyLinkedList();
	pay1 = (Payload*) malloc(sizeof(Room));
	pay1->roomNumber = 1;
	savePayload(case1, pay1);
	pay3 = (Payload*) malloc(sizeof(Room));
	pay3->roomNumber = 3;
	savePayload(case1, pay3);
	Payload* another = (Payload*) malloc(sizeof(Room));
	another->roomNumber=2;
	ans = removeFromList(case1, another);
	if((ans != case1))
	{
		ok = false;
	}
	printf("testRemove case 6 with %d\n", ok); fflush(stdout);
	return ok;
}

bool testPrintHistory()
{
	bool ok = true;
	return ok;
}
